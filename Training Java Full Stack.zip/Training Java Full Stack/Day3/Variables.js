console.log("Start");
var a = 10;
console.log(a)
let b = 20;
console.log(b)
const c = 30;
console.log(c)
console.log("end")